<?php
declare(strict_types=1);

/**
 * Contact form handler.
 *
 * Security measures in place:
 * - CSRF token verified against the session before processing anything
 * - Honeypot field ("company") rejects bot submissions silently
 * - Simple session-based rate limit (1 submission per 20 seconds) to
 *   slow down basic spam/abuse without needing a database
 * - All user input is validated server-side (never trust client-side
 *   validation alone) and stripped of CR/LF before use in mail
 *   headers, which prevents email header injection attacks
 * - Errors never expose internals — validation failures redirect back
 *   with a friendly flash message, nothing is echoed raw
 *
 * Flow: POST /contact/submit -> validate -> send mail -> redirect
 * back to /contact (PRG pattern, so refreshing never resubmits).
 */

function contact_csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/** Strips anything that could be used for header injection via mail(). */
function contact_clean_header_value(string $value): string
{
    return trim(str_replace(["\r", "\n", "%0a", "%0d"], '', $value));
}

/**
 * Builds the branded HTML email body. Table-based layout with fully
 * inline styles — this is deliberate, not old-fashioned: email clients
 * (Outlook especially) don't reliably support <style> blocks, flexbox,
 * or grid, so tables + inline styles are still the only safe way to
 * guarantee consistent rendering across Gmail, Outlook, and mobile mail apps.
 */
function contact_build_html_email(
    string $fullName,
    string $email,
    string $phone,
    string $reachingOutFor,
    string $helpWith,
    string $message
): string {
    $rows = [
        'Name' => $fullName,
        'Email' => $email,
        'Phone' => $phone !== '' ? $phone : 'Not provided',
        'Reaching out for' => $reachingOutFor,
        'Needs help with' => $helpWith,
    ];

    $rowsHtml = '';
    foreach ($rows as $label => $value) {
        $rowsHtml .= '
          <tr>
            <td style="padding:10px 0;border-bottom:1px solid #EFEFEF;color:#6B7670;font-size:12px;width:150px;vertical-align:top;font-family:Arial,Helvetica,sans-serif;">' . htmlspecialchars($label) . '</td>
            <td style="padding:10px 0;border-bottom:1px solid #EFEFEF;color:#1F2933;font-size:13px;font-weight:bold;vertical-align:top;font-family:Arial,Helvetica,sans-serif;">' . htmlspecialchars($value) . '</td>
          </tr>';
    }

    $messageHtml = nl2br(htmlspecialchars($message));
    $logoUrl = 'https://tri-chiwellness.com/assets/img/logo.png';

    return <<<HTML
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"></head>
<body style="margin:0;padding:0;background:#F7F3EA;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#F7F3EA;padding:32px 16px;">
    <tr>
      <td align="center">
        <table role="presentation" width="560" cellpadding="0" cellspacing="0" style="max-width:560px;width:100%;background:#FFFFFF;border-radius:16px;overflow:hidden;">

          <tr>
            <td style="background:#0F4C4A;padding:26px 32px;">
              <img src="{$logoUrl}" alt="Tri-Chi Wellness" width="36" height="36" style="vertical-align:middle;border-radius:8px;display:inline-block;">
              <span style="color:#FFFFFF;font-size:17px;font-weight:bold;vertical-align:middle;margin-left:12px;font-family:Arial,Helvetica,sans-serif;">Tri-Chi Wellness</span>
            </td>
          </tr>

          <tr>
            <td style="padding:32px;">
              <h1 style="margin:0 0 6px;color:#1F2933;font-size:20px;font-family:Arial,Helvetica,sans-serif;">New contact form message</h1>
              <p style="margin:0 0 24px;color:#6B7670;font-size:13px;font-family:Arial,Helvetica,sans-serif;">Someone reached out through the website. Details below.</p>

              <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;margin-bottom:22px;">
                {$rowsHtml}
              </table>

              <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#F7F3EA;border-radius:10px;">
                <tr>
                  <td style="padding:18px 20px;">
                    <p style="margin:0 0 8px;color:#6B7670;font-size:12px;font-family:Arial,Helvetica,sans-serif;">Message</p>
                    <p style="margin:0;color:#1F2933;font-size:14px;line-height:1.6;font-family:Arial,Helvetica,sans-serif;">{$messageHtml}</p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <tr>
            <td style="background:#F7F3EA;padding:18px 32px;text-align:center;">
              <p style="margin:0;color:#6B7670;font-size:11.5px;font-family:Arial,Helvetica,sans-serif;">Sent automatically from the contact form at tri-chiwellness.com</p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>
HTML;
}

/**
 * Sends a multipart email: an HTML version for clients that render it
 * (nearly all of them), plus a plain-text alternative for the rare
 * client that can't. This is the correct way to send styled email via
 * PHP's mail() — a single Content-Type: text/html header alone works
 * in most inboxes, but multipart/alternative is the properly compliant
 * approach and avoids ever showing raw HTML tags as text.
 */
function contact_send_mail(string $to, string $subject, string $htmlBody, string $plainBody, string $replyToName, string $replyToEmail): bool
{
    $boundary = 'ContactForm_' . bin2hex(random_bytes(16));

    $headers = [];
    $headers[] = 'From: Tri-Chi Wellness Website <no-reply@tri-chiwellness.com>';
    $headers[] = "Reply-To: {$replyToName} <{$replyToEmail}>";
    $headers[] = 'MIME-Version: 1.0';
    $headers[] = "Content-Type: multipart/alternative; boundary=\"{$boundary}\"";
    $headers[] = 'X-Mailer: PHP/' . phpversion();

    $body  = "--{$boundary}\r\n";
    $body .= "Content-Type: text/plain; charset=UTF-8\r\n";
    $body .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
    $body .= $plainBody . "\r\n\r\n";

    $body .= "--{$boundary}\r\n";
    $body .= "Content-Type: text/html; charset=UTF-8\r\n";
    $body .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
    $body .= $htmlBody . "\r\n\r\n";

    $body .= "--{$boundary}--";

    return @mail($to, $subject, $body, implode("\r\n", $headers));
}

function contact_handle_submit(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        header('Location: /contact');
        exit;
    }

    // --- CSRF check ---------------------------------------------------
    $submittedToken = $_POST['csrf_token'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'] ?? '', $submittedToken)) {
        $_SESSION['contact_flash'] = [
            'type' => 'error',
            'message' => 'Your session expired before the form was submitted. Please try again.',
        ];
        header('Location: /contact');
        exit;
    }

    // --- Honeypot ------------------------------------------------------
    if (!empty($_POST['company'])) {
        header('Location: /contact?sent=1');
        exit;
    }

    // --- Basic rate limiting -------------------------------------------
    $now = time();
    if (!empty($_SESSION['contact_last_submit']) && ($now - $_SESSION['contact_last_submit']) < 20) {
        $_SESSION['contact_flash'] = [
            'type' => 'error',
            'message' => "You're submitting a bit fast — please wait a few seconds and try again.",
        ];
        header('Location: /contact');
        exit;
    }

    // --- Gather + validate input -----------------------------------------
    $fullName = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $reachingOutFor = trim($_POST['reaching_out_for'] ?? 'Myself');
    $helpWith = trim($_POST['help_with'] ?? 'Not sure yet');
    $message = trim($_POST['message'] ?? '');

    $errors = [];

    if ($fullName === '' || strlen($fullName) > 100) {
        $errors[] = 'Please enter your full name.';
    }
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }
    if ($message === '' || strlen($message) > 3000) {
        $errors[] = 'Please enter a message (up to 3000 characters).';
    }
    if ($phone !== '' && !preg_match('/^[0-9+\-\s()]{5,20}$/', $phone)) {
        $errors[] = 'Please enter a valid phone number.';
    }

    if (!empty($errors)) {
        $_SESSION['contact_flash'] = [
            'type' => 'error',
            'message' => implode(' ', $errors),
        ];
        $_SESSION['contact_old_input'] = [
            'full_name' => $fullName,
            'email' => $email,
            'phone' => $phone,
            'reaching_out_for' => $reachingOutFor,
            'help_with' => $helpWith,
            'message' => $message,
        ];
        header('Location: /contact');
        exit;
    }

    // --- Send email ------------------------------------------------------
    $to = 'Trichi.wellness@gmail.com';
    //  $to = 'destinyfrosh952@gmail.com';
    $subject = 'New contact form message — ' . contact_clean_header_value($helpWith);

    $safeEmail = contact_clean_header_value($email);
    $safeName = contact_clean_header_value($fullName);

    $plainBody  = "You have a new message from the Tri-Chi Wellness contact form.\n\n";
    $plainBody .= "Name: {$fullName}\n";
    $plainBody .= "Email: {$email}\n";
    $plainBody .= "Phone: " . ($phone !== '' ? $phone : 'Not provided') . "\n";
    $plainBody .= "Reaching out for: {$reachingOutFor}\n";
    $plainBody .= "Needs help with: {$helpWith}\n\n";
    $plainBody .= "Message:\n{$message}\n";

    $htmlBody = contact_build_html_email($fullName, $email, $phone, $reachingOutFor, $helpWith, $message);

    $sent = contact_send_mail($to, $subject, $htmlBody, $plainBody, $safeName, $safeEmail);

    $_SESSION['contact_last_submit'] = $now;
    unset($_SESSION['contact_old_input']);

    if ($sent) {
        $_SESSION['contact_flash'] = [
            'type' => 'success',
            'message' => "Thanks, {$fullName} — your message has been sent. Our care team will be in touch within 24–48 hours.",
        ];
        header('Location: /contact?sent=1');
    } else {
        error_log('Contact form: mail() failed to send for ' . $safeEmail);
        $_SESSION['contact_flash'] = [
            'type' => 'error',
            'message' => 'Sorry, something went wrong sending your message. Please try again, or email us directly.',
        ];
        header('Location: /contact');
    }
    exit;
}