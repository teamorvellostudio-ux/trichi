<?php
/**
 * About page.
 * Built from full-resolution desktop + mobile screenshots.
 *

 */
 $canonicalUrl = 'https://tri-chiwellness.com/about';
$pageTitle = 'About Us | Tri-Chi Wellness';
$pageDescription = "Tri-Chi Wellness was created for people and families who need more than a quick answer — a calm, private space to talk, feel listened to, and receive guidance that fits your needs.";
$activeNav = 'about';

require __DIR__ . '/../layouts/header.php';
?>

<main>
  <!-- ================= ABOUT HERO ================= -->
  <section class="about-hero">
    <div class="container about-hero__row">
      <div class="about-hero__collage" data-reveal="scale">
        <img src="/assets/img/about-5.png" alt="Client in a quiet, private conversation by a window" loading="lazy">
      </div>
    
      <div class="about-hero__center" data-reveal="fade" data-reveal-delay="150">
        <h1>About Us</h1>
      </div>
    
      <div class="about-hero__collage" data-reveal="scale" data-reveal-delay="100">
        <img src="/assets/img/about-1.png" alt="Provider listening attentively to a client in a warm, plant-filled space" loading="lazy">
      </div>
    </div>

    <div class="container about-hero__copy">
      <p data-reveal="up"> 
        <strong>Tri-Chi Wellness was created for people and families who need more than a quick answer.</strong>
        <span> We provide a calm, private space where you can talk through what you're facing, </span>
        <strong>feel listened to,</strong>
        <span> and receive guidance </span>
        <strong>that fits your needs.</strong>
      </p>
      <p>
        <span data-reveal="up" data-reveal-delay="120">Led by Dr Paula Christian, DNP, PMHNP-BC, </span>
        <strong>our care is built on compassion, respect, and the belief</strong>
        <span> that no one should have to figure out their mental health alone.</span>
      </p>
    </div>

    <div class="container about-hero__since">
      <span>Since 2012</span>
      <span class="for_phone">Since 2012</span>
    </div>
  </section>

  <!-- ================= OVER VALUES ================= -->
  <section class="values">
    <div class="container">
      <h2 data-reveal="up" >Our Values</h2>
      <p class="values__subtext" data-reveal="up" data-reveal-delay="100">The principles behind the way we care.</p>

      <div class="values__grid">
          <div class="values__grid-track">
        <article class="value-card value-card--cream" data-reveal="scale">
          <div class="value-card__icon">
            <svg viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M15 21.25C15 16.9402 16.712 12.807 19.7595 9.75952C22.807 6.71205 26.9402 5 31.25 5C35.5598 5 39.693 6.71205 42.7405 9.75952C45.7879 12.807 47.5 16.9402 47.5 21.25C47.5 36.25 32.5 36.25 32.5 46.25C32.5 47.3991 32.2737 48.5369 31.8339 49.5985C31.3942 50.6601 30.7497 51.6247 29.9372 52.4372C29.1247 53.2497 28.1601 53.8942 27.0985 54.3339C26.0369 54.7737 24.8991 55 23.75 55C22.6009 55 21.4631 54.7737 20.4015 54.3339C19.3399 53.8942 18.3753 53.2497 17.5628 52.4372C16.7503 51.6247 16.1058 50.6601 15.6661 49.5985C15.2263 48.5369 15 47.3991 15 46.25" stroke="#0F4C4A" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M37.5 21.25C37.5 19.5924 36.8415 18.0027 35.6694 16.8306C34.4973 15.6585 32.9076 15 31.25 15C29.5924 15 28.0027 15.6585 26.8306 16.8306C25.6585 18.0027 25 19.5924 25 21.25V23.75C26.3261 23.75 27.5979 24.2768 28.5355 25.2145C29.4732 26.1521 30 27.4239 30 28.75C30 30.0761 29.4732 31.3479 28.5355 32.2855C27.5979 33.2232 26.3261 33.75 25 33.75" stroke="#0F4C4A" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>

          </div>
          <h3>Listening First</h3>
          <p>We take time to understand what each person is carrying before offering guidance. Care begins with feeling heard.</p>
        </article>

        <article class="value-card value-card--sage" data-reveal="scale" data-reveal-delay="150">
          <div class="value-card__icon">
            <svg viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M50 32.4999C50 44.9999 41.25 51.2499 30.85 54.8749C30.3054 55.0595 29.7138 55.0506 29.175 54.8499C18.75 51.2499 10 44.9999 10 32.4999V14.9999C10 14.3369 10.2634 13.701 10.7322 13.2321C11.2011 12.7633 11.837 12.4999 12.5 12.4999C17.5 12.4999 23.75 9.4999 28.1 5.6999C28.6296 5.2474 29.3034 4.99878 30 4.99878C30.6966 4.99878 31.3704 5.2474 31.9 5.6999C36.275 9.5249 42.5 12.4999 47.5 12.4999C48.163 12.4999 48.7989 12.7633 49.2678 13.2321C49.7366 13.701 50 14.3369 50 14.9999V32.4999Z" stroke="black" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M15.9399 47.2751C17.0067 44.4055 18.926 41.9311 21.44 40.1841C23.954 38.4371 26.9424 37.5011 30.0038 37.502C33.0652 37.5028 36.0531 38.4403 38.5662 40.1887C41.0792 41.937 42.9972 44.4124 44.0624 47.2826" stroke="black" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M30 37.5C35.5228 37.5 40 33.0228 40 27.5C40 21.9772 35.5228 17.5 30 17.5C24.4772 17.5 20 21.9772 20 27.5C20 33.0228 24.4772 37.5 30 37.5Z" stroke="black" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>

          </div>
          <h3>Privacy &amp; Respect</h3>
          <p>Every story is personal. We create a space where people are treated with dignity and care.</p>
        </article>
        
        <article class="value-card value-card--cream" data-reveal="scale" data-reveal-delay="250">
          <div class="value-card__icon">
            <svg viewBox="0 0 55 47" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M28.2725 6.80975L21.215 13.7148C20.2776 14.6524 19.7511 15.9239 19.7511 17.2498C19.7511 18.5756 20.2776 19.8471 21.215 20.7848C22.1526 21.7221 23.4242 22.2487 24.75 22.2487C26.0758 22.2487 27.3474 21.7221 28.285 20.7848L32.56 16.5098C33.1195 15.95 33.7838 15.506 34.515 15.203C35.2461 14.9001 36.0298 14.7441 36.8212 14.7441C37.6127 14.7441 38.3964 14.9001 39.1275 15.203C39.8587 15.506 40.523 15.95 41.0825 16.5098L45.785 21.2148C46.7224 22.1524 47.2489 23.4239 47.2489 24.7498C47.2489 26.0756 46.7224 27.3471 45.785 28.2847C49.75 24.3197 52.25 20.9998 52.25 15.9998C52.2499 13.2178 51.406 10.5012 49.8297 8.20891C48.2533 5.91661 46.0187 4.1564 43.421 3.16075C40.8232 2.1651 37.9846 1.98086 35.28 2.63236C32.5753 3.28386 30.1319 4.74045 28.2725 6.80975ZM45.785 28.2847C45.2919 28.7779 44.7065 29.1691 44.0622 29.436C43.4179 29.7029 42.7274 29.8403 42.03 29.8403C41.3326 29.8403 40.6421 29.7029 39.9978 29.436C39.3535 29.1691 38.7681 28.7779 38.275 28.2847C38.8089 28.7675 39.239 29.3538 39.5393 30.0079C39.8396 30.662 40.0038 31.3704 40.0219 32.0899C40.04 32.8095 39.9116 33.5252 39.6445 34.1936C39.3774 34.862 38.9772 35.4691 38.4683 35.978C37.9593 36.487 37.3522 36.8872 36.6838 37.1542C36.0154 37.4213 35.2997 37.5497 34.5802 37.5316C33.8606 37.5135 33.1523 37.3494 32.4981 37.0491C31.844 36.7488 31.2578 36.3186 30.775 35.7847C31.2685 36.2763 31.6603 36.8604 31.9279 37.5035C32.1955 38.1466 32.3337 38.8361 32.3347 39.5327C32.3356 40.2292 32.1992 40.9191 31.9333 41.563C31.6674 42.2068 31.2772 42.7919 30.785 43.2848C30.3099 43.76 29.744 44.1345 29.1209 44.3861C28.4978 44.6377 27.8305 44.7611 27.1586 44.7489C26.4868 44.7368 25.8243 44.5894 25.2107 44.3155C24.5972 44.0416 24.0451 43.6468 23.5875 43.1548L9.75 29.7498C6 25.9998 2.25 21.7498 2.25 15.9998C2.25056 13.218 3.09485 10.5018 4.6714 8.20986C6.24794 5.91796 8.48257 4.15814 11.0802 3.1628C13.6778 2.16747 16.5162 1.98343 19.2206 2.63501C21.925 3.28658 24.3682 4.74311 26.2275 6.81225C26.5055 7.07059 26.871 7.21397 27.2505 7.21351C27.63 7.21304 27.9952 7.06877 28.2725 6.80975" stroke="#0F4C4A" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
          </div>
          <h3>Guided Support</h3>
          <p>We help individuals and families understand their needs, explore their options, and take the next step with clarity..</p>
        </article>
        
        
        
        
        
        <article class="value-card value-card--cream" data-reveal="scale" data-reveal-delay="350">
          <div class="value-card__icon">
            <svg  viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M15 21.25C15 16.9402 16.712 12.807 19.7595 9.75952C22.807 6.71205 26.9402 5 31.25 5C35.5598 5 39.693 6.71205 42.7405 9.75952C45.7879 12.807 47.5 16.9402 47.5 21.25C47.5 36.25 32.5 36.25 32.5 46.25C32.5 47.3991 32.2737 48.5369 31.8339 49.5985C31.3942 50.6601 30.7497 51.6247 29.9372 52.4372C29.1247 53.2497 28.1601 53.8942 27.0985 54.3339C26.0369 54.7737 24.8991 55 23.75 55C22.6009 55 21.4631 54.7737 20.4015 54.3339C19.3399 53.8942 18.3753 53.2497 17.5628 52.4372C16.7503 51.6247 16.1058 50.6601 15.6661 49.5985C15.2263 48.5369 15 47.3991 15 46.25" stroke="#0F4C4A" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M37.5 21.25C37.5 19.5924 36.8415 18.0027 35.6694 16.8306C34.4973 15.6585 32.9076 15 31.25 15C29.5924 15 28.0027 15.6585 26.8306 16.8306C25.6585 18.0027 25 19.5924 25 21.25V23.75C26.3261 23.75 27.5979 24.2768 28.5355 25.2145C29.4732 26.1521 30 27.4239 30 28.75C30 30.0761 29.4732 31.3479 28.5355 32.2855C27.5979 33.2232 26.3261 33.75 25 33.75" stroke="#0F4C4A" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>

          </div>
          <h3>Listening First</h3>
          <p>We take time to understand what each person is carrying before offering guidance. Care begins with feeling heard.</p>
        </article>

        <article class="value-card value-card--sage" data-reveal="scale" data-reveal-delay="450">
          <div class="value-card__icon">
            <svg viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M50 32.4999C50 44.9999 41.25 51.2499 30.85 54.8749C30.3054 55.0595 29.7138 55.0506 29.175 54.8499C18.75 51.2499 10 44.9999 10 32.4999V14.9999C10 14.3369 10.2634 13.701 10.7322 13.2321C11.2011 12.7633 11.837 12.4999 12.5 12.4999C17.5 12.4999 23.75 9.4999 28.1 5.6999C28.6296 5.2474 29.3034 4.99878 30 4.99878C30.6966 4.99878 31.3704 5.2474 31.9 5.6999C36.275 9.5249 42.5 12.4999 47.5 12.4999C48.163 12.4999 48.7989 12.7633 49.2678 13.2321C49.7366 13.701 50 14.3369 50 14.9999V32.4999Z" stroke="black" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M15.9399 47.2751C17.0067 44.4055 18.926 41.9311 21.44 40.1841C23.954 38.4371 26.9424 37.5011 30.0038 37.502C33.0652 37.5028 36.0531 38.4403 38.5662 40.1887C41.0792 41.937 42.9972 44.4124 44.0624 47.2826" stroke="black" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M30 37.5C35.5228 37.5 40 33.0228 40 27.5C40 21.9772 35.5228 17.5 30 17.5C24.4772 17.5 20 21.9772 20 27.5C20 33.0228 24.4772 37.5 30 37.5Z" stroke="black" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>

          </div>
          <h3>Privacy &amp; Respect</h3>
          <p>Every story is personal. We create a space where people are treated with dignity and care.</p>
        </article>
        
        <article class="value-card value-card--cream" data-reveal="scale" data-reveal-delay="550">
          <div class="value-card__icon">
            <svg viewBox="0 0 55 47" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M28.2725 6.80975L21.215 13.7148C20.2776 14.6524 19.7511 15.9239 19.7511 17.2498C19.7511 18.5756 20.2776 19.8471 21.215 20.7848C22.1526 21.7221 23.4242 22.2487 24.75 22.2487C26.0758 22.2487 27.3474 21.7221 28.285 20.7848L32.56 16.5098C33.1195 15.95 33.7838 15.506 34.515 15.203C35.2461 14.9001 36.0298 14.7441 36.8212 14.7441C37.6127 14.7441 38.3964 14.9001 39.1275 15.203C39.8587 15.506 40.523 15.95 41.0825 16.5098L45.785 21.2148C46.7224 22.1524 47.2489 23.4239 47.2489 24.7498C47.2489 26.0756 46.7224 27.3471 45.785 28.2847C49.75 24.3197 52.25 20.9998 52.25 15.9998C52.2499 13.2178 51.406 10.5012 49.8297 8.20891C48.2533 5.91661 46.0187 4.1564 43.421 3.16075C40.8232 2.1651 37.9846 1.98086 35.28 2.63236C32.5753 3.28386 30.1319 4.74045 28.2725 6.80975ZM45.785 28.2847C45.2919 28.7779 44.7065 29.1691 44.0622 29.436C43.4179 29.7029 42.7274 29.8403 42.03 29.8403C41.3326 29.8403 40.6421 29.7029 39.9978 29.436C39.3535 29.1691 38.7681 28.7779 38.275 28.2847C38.8089 28.7675 39.239 29.3538 39.5393 30.0079C39.8396 30.662 40.0038 31.3704 40.0219 32.0899C40.04 32.8095 39.9116 33.5252 39.6445 34.1936C39.3774 34.862 38.9772 35.4691 38.4683 35.978C37.9593 36.487 37.3522 36.8872 36.6838 37.1542C36.0154 37.4213 35.2997 37.5497 34.5802 37.5316C33.8606 37.5135 33.1523 37.3494 32.4981 37.0491C31.844 36.7488 31.2578 36.3186 30.775 35.7847C31.2685 36.2763 31.6603 36.8604 31.9279 37.5035C32.1955 38.1466 32.3337 38.8361 32.3347 39.5327C32.3356 40.2292 32.1992 40.9191 31.9333 41.563C31.6674 42.2068 31.2772 42.7919 30.785 43.2848C30.3099 43.76 29.744 44.1345 29.1209 44.3861C28.4978 44.6377 27.8305 44.7611 27.1586 44.7489C26.4868 44.7368 25.8243 44.5894 25.2107 44.3155C24.5972 44.0416 24.0451 43.6468 23.5875 43.1548L9.75 29.7498C6 25.9998 2.25 21.7498 2.25 15.9998C2.25056 13.218 3.09485 10.5018 4.6714 8.20986C6.24794 5.91796 8.48257 4.15814 11.0802 3.1628C13.6778 2.16747 16.5162 1.98343 19.2206 2.63501C21.925 3.28658 24.3682 4.74311 26.2275 6.81225C26.5055 7.07059 26.871 7.21397 27.2505 7.21351C27.63 7.21304 27.9952 7.06877 28.2725 6.80975" stroke="#0F4C4A" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
          </div>
          <h3>Guided Support</h3>
          <p>We help individuals and families understand their needs, explore their options, and take the next step with clarity..</p>
        </article>
        
    </div>
      </div>
    </div>
  </section>

  <?php require __DIR__ . '/../partials/_approach.php'; ?>

  <?php require __DIR__ . '/../partials/_testimonials.php'; ?>
</main>

<?php require __DIR__ . '/../layouts/footer.php'; ?>