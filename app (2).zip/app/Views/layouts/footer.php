<footer class="site-footer">
  <div class="container">
    <div class="newsletter">
      <div class="newsletter__copy">
        <h2>Get the latest updates from Tri-Chi Wellness.</h2>
        <p>Receive clinic updates, wellness resources, and helpful information about mental health care directly in your inbox.</p>
      </div>

      <form class="newsletter__form" action="/subscribe" method="POST">
        <span class="newsletter__label">Stay Informed</span>
        <div class="newsletter__row">
          <input type="email" name="email" placeholder="Enter your email" required aria-label="Email address">
          <button type="submit" class="btn btn--light">Subscribe</button>
        </div>
      </form>

      <div class="newsletter__seal" aria-hidden="true">
        <!--<svg viewBox="0 0 64 64" width="56" height="56">-->
        <!--  <circle cx="32" cy="32" r="30" fill="#E6B622"/>-->
        <!--  <circle cx="32" cy="32" r="24" fill="none" stroke="#FFFFFF" stroke-width="1.5" stroke-dasharray="2 3"/>-->
        <!--  <text x="32" y="29" text-anchor="middle" font-size="10" font-weight="700" fill="#0F4C4A" font-family="Poppins, sans-serif">CARF</text>-->
        <!--  <text x="32" y="40" text-anchor="middle" font-size="6" fill="#0F4C4A" font-family="Inter, sans-serif">ACCREDITED</text>-->
        <!--</svg>-->
        <img src="/assets/img/image1.png" alt="carf " loading="lazy" width="96" height="96">
      </div>
    </div>
  </div>

  <div class="footer-bar">
    <div class="container footer-bar__inner">
      <div class="footer-bar__brand">
        <div class="footer-bar__logo">
          <span class="brand-dark">Tri-chi</span> <span class="brand-accent">wellness</span>
        </div>
        <p class="footer-bar__tagline">Guiding you toward better wellbeing.</p>
      </div>

      <nav class="footer-bar__links" aria-label="Footer">
        <a href="/">Home</a>
        <a href="/about">About</a>
        <a href="/services">Services</a>
        <a href="/contact">Contact</a>
      </nav>
    </div>
  </div>
</footer>

<script src="<?= asset_url('/assets/js/main.js') ?>" defer></script>
</body>
</html>