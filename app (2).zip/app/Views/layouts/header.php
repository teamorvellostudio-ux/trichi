<?php
/**
 * Header / Navigation partial
 * Expects (optional): $activeNav — string matching one of
 * 'home' | 'about' | 'services' | 'contact' to mark the active link.
 */
$activeNav = $activeNav ?? 'home';
/**
 * Cache-busting helper. Appends the asset file's last-modified
 * timestamp as a ?v= query string, so browsers (including mobile,
 * where there's no easy hard-refresh gesture) automatically fetch
 * the new version the moment the file changes on the server —
 * no manual cache clearing ever needed, on any device.
 */
if (!function_exists('asset_url')) {
    function asset_url(string $path): string
    {
        $fsPath = ($_SERVER['DOCUMENT_ROOT'] ?? '') . $path;
        $version = @filemtime($fsPath);
        return $path . '?v=' . ($version ?: '1');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($pageTitle ?? 'Tri-chi Wellness — Behavioral Health Support') ?></title>
  <meta name="description" content="<?= htmlspecialchars($pageDescription ?? 'Tri-chi Wellness provides professional behavioral health support, medication management, and care guidance for individuals and families seeking trusted mental health care.') ?>">
  <link rel="canonical" href="<?= htmlspecialchars($canonicalUrl ?? '#') ?>">

  <meta property="og:title" content="<?= htmlspecialchars($pageTitle ?? 'Tri-chi Wellness') ?>">
  <meta property="og:description" content="<?= htmlspecialchars($pageDescription ?? '') ?>">
  <meta property="og:type" content="website">
  <meta property="og:url" content="<?= htmlspecialchars($canonicalUrl ?? 'https://tri-chiwellness.com/') ?>">
<meta property="og:site_name" content="Tri-chi Wellness">
  <meta name="twitter:card" content="summary_large_image">
  <link rel="icon" type="image/png" href="<?= asset_url('/assets/img/favicon.png') ?>">
  <link rel="icon" type="image/svg+xml" href="<?= asset_url('/assets/img/favicon.svg') ?>">
  <link rel="apple-touch-icon" href="<?= asset_url('/assets/img/tri-chiwellness.png') ?>">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= asset_url('/assets/css/style.css') ?>">
  <script>document.documentElement.classList.add('js');</script>
  <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "MedicalClinic",
  "name": "Tri-Chi Wellness",
  "url": "https://tri-chiwellness.com/",
  "image": "https://tri-chiwellness.com/assets/img/logo.png",
  "email": "Trichi.wellness@gmail.com",
  "telephone": "+1-43-858-0326",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "4 E Rolling Crossroads, STE 100",
    "addressLocality": "Catonsville",
    "addressRegion": "MD",
    "postalCode": "21228",
    "addressCountry": "US"
  },
  "medicalSpecialty": "Psychiatric",
  "employee": {
    "@type": "Person",
    "name": "Dr Paula Christian",
    "honorificSuffix": "DNP, PMHNP-BC"
  },
  "description": "Professional behavioral health support, therapy and counseling, and medication management for individuals and families."
}
</script>
</head>
<body>

<header class="site-header">
  <div class="container nav">
    <a href="/" class="nav__logo" aria-label="Tri-chi Wellness home">
      <!--<svg class="nav__logo-icon" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">-->
      <!--  <path d="M16 16C16 16 14 8 8 8C8 8 8 16 16 16Z" fill="#0F4C4A"/>-->
      <!--  <path d="M16 16C16 16 18 7 25 7C25 7 25 16 16 16Z" fill="#E8A33D"/>-->
      <!--  <path d="M16 16C16 16 24 15 24 22C24 22 16 22 16 16Z" fill="#628B8B"/>-->
      <!--  <path d="M16 16C16 16 9 17 9 23C9 23 16 24 16 16Z" fill="#2F6E5E"/>-->
      <!--  <circle cx="16" cy="16" r="2.5" fill="#F4C242"/>-->
      <!--</svg>-->
      <img src="/assets/img/tri-chiwellness.png" alt="Client reflecting during an individual counseling session" loading="lazy" class="nav__logo-icon">
      
      <span class="nav__logo-text"><span class="brand-dark">Tri-chi</span> <span class="brand-accent">wellness</span></span>
    </a>

    <nav class="nav__links" aria-label="Primary">
      <a href="/" class="<?= $activeNav === 'home' ? 'is-active' : '' ?>">Home</a>
      <a href="/about" class="<?= $activeNav === 'about' ? 'is-active' : '' ?>">About</a>
      <a href="/services" class="<?= $activeNav === 'services' ? 'is-active' : '' ?>">Services</a>
      <a href="/contact" class="<?= $activeNav === 'contact' ? 'is-active' : '' ?>">Contact</a>
    </nav>

    <a href="/contact" class="btn btn--primary nav__cta">Contact Us</a>

    <button class="nav__toggle" id="navToggle" aria-label="Open menu" aria-expanded="false" aria-controls="mobileMenu">
      <svg class="icon-burger" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
      <svg class="icon-close" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/></svg>
    </button>
  </div>

  <div class="mobile-menu" id="mobileMenu">
    <nav class="mobile-menu__links" aria-label="Primary mobile">
      <a href="/" class="<?= $activeNav === 'home' ? 'is-active' : '' ?>">Home</a>
      <a href="/about" class="<?= $activeNav === 'about' ? 'is-active' : '' ?>">About</a>
      <a href="/services" class="<?= $activeNav === 'services' ? 'is-active' : '' ?>">Services</a>
      <a href="/contact" class="<?= $activeNav === 'contact' ? 'is-active' : '' ?>">Contact</a>
    </nav>
    <!--<a href="/contact" class="btn btn--primary mobile-menu__cta">Contact Us</a>-->
    <!--<div class="mobile-menu__topbar">-->
  <a href="/" class="nav__logo" aria-label="Tri-chi Wellness home">
    <!-- same logo svg -->
  </a>
  <button class="mobile-menu__close" id="navClose" aria-label="Close menu">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/></svg>
  </button>
</div>
  </div>
</header>