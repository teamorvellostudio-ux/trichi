<?php
/**
 * Contact page.
 * Built from full-resolution desktop + mobile screenshots.
 * Uses the shared contact-section partial (also embedded on Home).
 */
$canonicalUrl = 'https://tri-chiwellness.com/contact';
$pageTitle = 'Contact Us | Tri-Chi Wellness';
$pageDescription = 'Reach out to Tri-Chi Wellness by email, phone, or message. Our care team responds within 24–48 hours.';
$activeNav = 'contact';
$contactHeadingTag = 'h1';

require __DIR__ . '/../layouts/header.php';
?>

<main>
  <?php require __DIR__ . '/../partials/_contact-section.php'; ?>
</main>

<?php require __DIR__ . '/../layouts/footer.php'; ?>