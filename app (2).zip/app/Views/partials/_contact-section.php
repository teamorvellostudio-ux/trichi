<?php
/**
 * Shared "Contact Us" section — info list + contact form.
 * Confirmed via screenshots to appear both as the full Contact page
 * AND embedded near the bottom of the homepage (before the newsletter/footer).
 *
 * Optional override:
 *   $contactHeadingTag — 'h1' on the dedicated Contact page, 'h2' when embedded elsewhere.
 */
$contactHeadingTag = $contactHeadingTag ?? 'h2';

$flash = $_SESSION['contact_flash'] ?? null;
unset($_SESSION['contact_flash']);
$old = $_SESSION['contact_old_input'] ?? [];
unset($_SESSION['contact_old_input']);

$wasSent = isset($_GET['sent']) && $_GET['sent'] === '1';
?>
<section class="contact-section">
  <div class="container contact-grid">
    <div class="contact-info" data-reveal="left">
      <<?= $contactHeadingTag ?>>Contact Us</<?= $contactHeadingTag ?>>

      <ul class="contact-info__list">
        <li class="contact-info__item">
          <span class="contact-info__icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M22 6l-10 7L2 6"/></svg>
          </span>
          <a href="mailto:Trichi.wellness@gmail.com">Trichi.wellness@gmail.com</a>
        </li>
        <li class="contact-info__item">
          <span class="contact-info__icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 6l7-3 8 3 7-3v15l-7 3-8-3-7 3V6z"/><path d="M8 3v15M16 6v15"/></svg>
          </span>
          <span>4 E Rolling Crossroads, STE 100 Catonsville, MD 21228</span>
        </li>
        <li class="contact-info__item">
  <span class="contact-info__icon">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.9v3a2 2 0 01-2.2 2 19.8 19.8 0 01-8.6-3.1 19.5 19.5 0 01-6-6 19.8 19.8 0 01-3.1-8.7A2 2 0 014.1 2h3a2 2 0 012 1.7c.1.9.3 1.8.6 2.7a2 2 0 01-.4 2.1L8 9.9a16 16 0 006 6l1.4-1.4a2 2 0 012.1-.4c.9.3 1.8.5 2.7.6a2 2 0 011.8 2.2z"/></svg>
  </span>
  <a href="tel:+14433003923">443.300.3923</a> / <a href="tel:+12817047578">281-704-7578</a>
</li>
<li class="contact-info__item">
  <span class="contact-info__icon">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="4" width="16" height="16" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/></svg>
  </span>
  <span>Fax: 443.300.3927</span>
</li>
        <li class="contact-info__item">
          <span class="contact-info__icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="3" width="16" height="18" rx="2"/><circle cx="12" cy="10" r="3"/><path d="M7 20c.5-2.5 2.3-4 5-4s4.5 1.5 5 4"/></svg>
          </span>
          <span>Dr Paula Christian&nbsp; DNP PMHNP-BC</span>
        </li>
      </ul>
    </div>

    <div class="contact-form-card" data-reveal="right">
      <div class="contact-form-card__deco" aria-hidden="true">
        <!--<svg viewBox="0 0 60 70" class="contact-form-card__clip">-->
        <!--  <path d="M20 2h20v34a4 4 0 01-4 4h-3v18a3 3 0 01-6 0V40h-3a4 4 0 01-4-4V2z" fill="none" stroke="#B9BEC0" stroke-width="2"/>-->
        <!--  <rect x="14" y="30" width="32" height="20" rx="3" fill="#0F4C4A"/>-->
        <!--</svg>-->
        <img src="/assets/img/CUSTOMIZED1.png" alt="clip" loading="lazy" class="contact-form-card__clip" >
        <svg class="contact-form-card__zigzag" viewBox="0 0 400 20" preserveAspectRatio="none" aria-hidden="true">
          <polyline points="0,20 20,2 40,20 60,2 80,20 100,2 120,20 140,2 160,20 180,2 200,20 220,2 240,20 260,2 280,20 300,2 320,20 340,2 360,20 380,2 400,20" fill="none" stroke="#E7E2D6" stroke-width="2"/>
        </svg>
      </div>

      <h3>Contact Form</h3>

      <?php if ($flash): ?>
        <div class="form-flash form-flash--<?= htmlspecialchars($flash['type']) ?>" role="status">
          <button type="button" class="form-flash__close" aria-label="Dismiss">&times;</button>
          <?= htmlspecialchars($flash['message']) ?>
        </div>
      <?php elseif ($wasSent): ?>
        <div class="form-flash form-flash--success" role="status">
          <button type="button" class="form-flash__close" aria-label="Dismiss">&times;</button>
          Thanks — your message has been sent. Our care team will be in touch within 12&ndash;24 hours.
        </div>
      <?php endif; ?>

      <form class="contact-form" action="/contact/submit" method="POST" novalidate>
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(contact_csrf_token()) ?>">

        <!-- Honeypot: hidden from real visitors via CSS, bots that
             auto-fill every field will get caught in ContactController. -->
        <div class="hp-field" aria-hidden="true">
          <label for="company">Company</label>
          <input type="text" id="company" name="company" tabindex="-1" autocomplete="off">
        </div>

        <label for="full_name">Full Name</label>
        <input type="text" id="full_name" name="full_name" placeholder="Enter your full name" value="<?= htmlspecialchars($old['full_name'] ?? '') ?>" required>

        <label for="email">Email Address</label>
        <input type="email" id="email" name="email" placeholder="Enter your email address" value="<?= htmlspecialchars($old['email'] ?? '') ?>" required>

        <label for="phone">Phone Number</label>
        <input type="tel" id="phone" name="phone" placeholder="Enter your phone number" value="<?= htmlspecialchars($old['phone'] ?? '') ?>">

        <label for="reaching_out_for">I am reaching out for</label>
        <?php $reachingOutOld = $old['reaching_out_for'] ?? 'Myself'; ?>
        <select id="reaching_out_for" name="reaching_out_for">
          <?php foreach (['Myself', 'A family member', 'Someone else'] as $opt): ?>
            <option <?= $reachingOutOld === $opt ? 'selected' : '' ?>><?= $opt ?></option>
          <?php endforeach; ?>
        </select>

        <label for="help_with">What do you need help with?</label>
        <?php $helpWithOld = $old['help_with'] ?? 'Therapy & Counseling'; ?>
        <select id="help_with" name="help_with">
          <?php foreach (['Therapy & Counseling', 'Medication Management', 'Not sure yet'] as $opt): ?>
            <option <?= $helpWithOld === $opt ? 'selected' : '' ?>><?= htmlspecialchars($opt) ?></option>
          <?php endforeach; ?>
        </select>

        <label for="message">Message</label>
        <textarea id="message" name="message" rows="4" placeholder="Tell us a little about what you are going through or what kind of support you are looking for."><?= htmlspecialchars($old['message'] ?? '') ?></textarea>

        <button type="submit" class="btn btn--primary contact-form__submit">Submit Message</button>
      </form>
    </div>
  </div>
</section>