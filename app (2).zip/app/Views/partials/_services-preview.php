<?php
/**
 * Shared "Care that helps you feel seen" 2-card services preview.
 * Confirmed via screenshots to repeat identically on Home and Services.
 *
 * Optional overrides (set before requiring this partial):
 *   $servicesEyebrow, $servicesHeading, $servicesSubtext
 */
$servicesEyebrow = $servicesEyebrow ?? 'Our Services';
$servicesHeading = $servicesHeading ?? 'Care that helps you feel seen, heard, and guided.';
$servicesSubtext = $servicesSubtext ?? 'Tri-Chi Wellness offers compassionate mental health support for individuals and families who need a safe place to be heard, guided, and cared for.';
?>
<section class="services">
  <div class="container">
    <span class="services__eyebrow" data-reveal="fade">
      <svg width="17" height="15" viewBox="0 0 17 15" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M4.75375 0.0226987C3.64125 0.161865 2.56875 0.722699 1.71458 1.6102C0.830418 2.5277 0.287918 3.63103 0.0604183 4.97103C-0.0195817 5.44187 -0.020415 6.52103 0.059585 6.95437C0.229585 7.88187 0.529585 8.64603 1.05458 9.48853C1.69459 10.516 2.79959 11.6602 4.12542 12.6685C5.02042 13.3485 6.55625 14.3277 7.29792 14.6902C7.66209 14.8685 8.07042 14.9877 8.31459 14.9877C8.73292 14.9877 9.27375 14.7619 10.2313 14.1869C11.3629 13.5077 12.4621 12.7394 13.2313 12.091C14.0696 11.3844 14.9604 10.4144 15.4546 9.67103C15.7663 9.2027 16.1538 8.43687 16.3071 7.9877C16.7438 6.70687 16.7513 5.30853 16.3271 3.9727C16.1771 3.49853 15.7763 2.69187 15.4904 2.2877C15.1613 1.82353 14.4813 1.1552 14.0363 0.859365C13.4892 0.483249 12.8733 0.219014 12.2238 0.0818653C11.7504 -0.0206347 10.9013 -0.0206347 10.4229 0.0818653C9.69375 0.238532 9.09625 0.521865 8.37708 1.0502C8.32375 1.08853 8.30542 1.08853 8.25209 1.0502C7.52792 0.517699 6.92125 0.231865 6.20625 0.0851988C5.81542 0.00519875 5.12709 -0.0248013 4.75375 0.0226987ZM11.9046 1.71853C13.1696 1.97937 14.2963 3.07937 14.7421 4.4877C14.8871 4.94603 14.9496 5.3102 14.9713 5.82353C14.9953 6.27146 14.9438 6.72023 14.8188 7.15103C14.7546 7.36187 14.6688 7.4277 14.2813 7.56187C13.9946 7.66103 13.4554 7.6677 13.1813 7.5752C12.7538 7.4302 12.6271 7.33603 11.8813 6.60187C11.4871 6.21437 11.0988 5.85603 11.0179 5.8052C10.7812 5.65606 10.506 5.57931 10.2263 5.58437C9.65375 5.58187 9.43875 5.69853 8.71708 6.40353C8.36042 6.7502 8.09875 6.97853 7.99292 7.03187C7.42125 7.32187 6.77458 7.29437 6.26208 6.95937C6.15933 6.89334 6.06307 6.81772 5.97459 6.73353C5.88171 6.63442 5.81959 6.51049 5.79578 6.37676C5.77196 6.24304 5.78747 6.10528 5.84042 5.9802C5.91959 5.80937 9.25292 2.4677 9.56459 2.24687C10.2954 1.72937 11.0888 1.5502 11.9046 1.71853Z" fill="#0F4C4A"/>
</svg>

      <?= htmlspecialchars($servicesEyebrow) ?>
    </span>
    <h2 class="services__heading" data-reveal="up" data-reveal-delay="80"><?= htmlspecialchars($servicesHeading) ?></h2>
    <p class="services__subtext"  data-reveal="up" data-reveal-delay="150"><?= htmlspecialchars($servicesSubtext) ?></p>

    <div class="services__grid">
      <article class="service-card" data-reveal="up">
        <div class="service-card__image">
          <img src="/assets/img/service-therapy.jpg" alt="Therapist and client in a counseling session" loading="lazy" width="400" height="300">
        </div>
        <h3>Therapy &amp; Counseling Services</h3>
        <p>A safe, confidential space to talk through emotional, behavioral, personal, or family challenges with professional guidance.</p>
      </article>

      <article class="service-card" data-reveal="up" data-reveal-delay="200">
        <div class="service-card__image">
          <img src="/assets/img/servcie-medication.png" alt="Clinician discussing medication management with a client" loading="lazy" width="400" height="300">
        </div>
        <h3>Medication Management</h3>
        <p>Thoughtful guidance for individuals who need help understanding, reviewing, or managing mental health medications with clarity and care.</p>
      </article>
    </div>
  </div>
</section>