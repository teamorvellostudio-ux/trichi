<?php
/**
 * Shared "Our Approach" carousel section.
 * Confirmed via screenshots to repeat identically on Home and About.
 */
?>
<section class="approach">
  <div class="container">
    <span class="approach__eyebrow" data-reveal="fade">Our Approach</span>
    <p class="approach__heading" data-reveal="up" data-reveal-delay="100">
      <strong>At Tri-Chi Wellness, we believe meaningful care starts with listening.</strong>
      <span> We support individuals and families through compassionate conversations, professional guidance, and care that is tailored to their needs.</span>
    </p>

    <div class="carousel" data-carousel>
      <div class="carousel__track">
        <div class="carousel__slide" data-pos="-2">
          <img src="/assets/img/approach-1.jpg" alt="Family sitting together on a couch during a supportive conversation" loading="lazy" width="420" height="440">
        </div>
        <div class="carousel__slide" data-pos="-1">
          <img src="/assets/img/approach-2.png" alt="Client reflecting during an individual counseling session" loading="lazy" width="420" height="440">
        </div>
        <div class="carousel__slide" data-pos="0">
          <img src="/assets/img/approach-3.png" alt="Therapist and client having an open conversation in a relaxed setting" loading="lazy" width="420" height="440">
        </div>
        <div class="carousel__slide" data-pos="1">
          <img src="/assets/img/approach-4.jpg" alt="Client speaking with a care provider about next steps" loading="lazy" width="420" height="440">
        </div>
        <div class="carousel__slide" data-pos="2">
          <img src="/assets/img/approach-5.jpg" alt="Provider reviewing care guidance with a client" loading="lazy" width="420" height="440">
        </div>
      </div>
    </div>
  </div>
</section>