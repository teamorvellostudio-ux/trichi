<?php
/**
 * Shared "What Our Client Say" auto-scrolling testimonial marquee.
 * Real names, roles, and quotes transcribed directly from the
 * Home/About/Services screenshots (confirmed identical across all three).
 */

$testimonials = [
  ['Natalie Warren', 'Administrative Assistant', "The care felt personal. I didn't feel like I was just another case. They listened carefully and explained everything in a way I could understand.", 'women/68'],
  ['Brian Mitchell', 'Small Business Owner', "I reached out for my younger sister, and they helped me understand how to support her without making the process feel confusing.", 'men/32'],
  ['Claire Johnson', 'Social Worker', "I contacted them for someone I care about, and they helped me understand what to do next without making the process feel overwhelming.", 'women/44'],
  ['Amelia Brooks', 'Elementary School Teacher', "I felt heard without feeling judged. The team helped me understand what I was going through and made it easier to take the next step.", 'women/12'],
  ['Marcus Reed', 'Operations Manager', "I was nervous about reaching out, but the process felt calm and private. I didn't feel rushed, and I finally felt like someone was listening.", 'men/54'],
];

?>
<section class="testimonials">
  <div class="container">
    <span class="testimonials__eyebrow" data-reveal="fade">Testimonials</span>
    <h2 class="testimonials__heading" data-reveal="up" data-reveal-delay="80">What Our Client Say</h2>
    <p class="testimonials__subtext" data-reveal="up" data-reveal-delay="150">Real care is felt in the way people are heard.</p>

    <div class="marquee-grid">
      <?php
      $columns = [
        array_slice($testimonials, 0, 3),
        array_slice(array_merge(array_slice($testimonials, 2), array_slice($testimonials, 0, 2)), 0, 3),
        array_slice(array_merge(array_slice($testimonials, 3), array_slice($testimonials, 0, 3)), 0, 3),
      ];
      ?>
      <?php foreach ($columns as $colIndex => $col): ?>
        <div class="marquee-col<?= $colIndex === 1 ? ' marquee-col--reverse' : '' ?>" data-reveal="fade" data-reveal-delay="<?= $colIndex * 120 ?>">
          <div class="marquee-col__inner">
            <?php foreach ($col as $t): ?>
              <div class="testimonial-card">
                <div class="testimonial-card__head">
                  <img class="testimonial-card__avatar" src="https://randomuser.me/api/portraits/<?= $t[3] ?>.jpg" alt="" loading="lazy">
                  <div>
                    <p class="testimonial-card__name"><?= htmlspecialchars($t[0]) ?></p>
                    <p class="testimonial-card__role"><?= htmlspecialchars($t[1]) ?></p>
                  </div>
                </div>
                <p class="quote">&ldquo;<?= htmlspecialchars($t[2]) ?>&rdquo;</p>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>