<?php
/**
 * Shared FAQ accordion. Questions transcribed directly from the
 * Services page screenshot. Answer copy was not visible in any
 * screenshot (accordions were shown collapsed) — answers below are
 * written to reasonably match each question and should be reviewed/
 * replaced with your actual policy language.
 *
 * Optional overrides:
 *   $faqButtonLabel, $faqButtonHref
 */
$faqButtonLabel = $faqButtonLabel ?? 'Send email';
$faqButtonHref = $faqButtonHref ?? 'mailto:Trichi.wellness@gmail.com';

$faqItems = [
  ['Do I need to know exactly what service I need before contacting you?', "Not at all. Many people reach out without knowing exactly what they need — that's part of what the first conversation is for. We'll help you figure out the right fit."],
  ['What services does Tri-Chi Wellness provide?', 'We provide therapy and counseling services along with medication management for individuals and families seeking behavioral health support.'],
  ['Is my information private?', 'Yes. Everything you share is kept confidential and handled in line with professional privacy standards.'],
  ['Can I reach out for someone else?', "Yes. Many people contact us on behalf of a family member or loved one — we'll help you understand how best to support them."],
  ['What happens after I send a message?', "Our care team reviews your message and follows up to understand your situation before recommending next steps."],
  ['What should I do in a crisis?', 'If you or someone else is in immediate danger, please call 911 or go to your nearest emergency room. This site is not monitored for emergencies.'],
];
?>
<section class="faq">
  <div class="container faq__grid">
    <div class="faq__col-left" data-reveal="left">
      <h2>Questions you may have before reaching out.</h2>

      <div class="faq__still">
        <h3>Still have a questions?</h3>
        <p>You do not need to have everything figured out before reaching out. Send us a message, and our care team will help you understand the next step.</p>
        <a href="<?= htmlspecialchars($faqButtonHref) ?>" class="btn btn--primary"><?= htmlspecialchars($faqButtonLabel) ?></a>
      </div>
    </div>

    <div class="faq__list">
      <?php foreach ($faqItems as $faq): ?>
        <div class="faq__item" data-reveal="up" data-reveal-delay="<?= $i * 60 ?>">
          <button class="faq__question" type="button" aria-expanded="false">
            <span><?= htmlspecialchars($faq[0]) ?></span>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
          </button>
          <div class="faq__answer">
            <p><?= htmlspecialchars($faq[1]) ?></p>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>