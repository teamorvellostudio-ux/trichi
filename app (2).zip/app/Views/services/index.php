<?php
/**
 * Services page.
 * Built from full-resolution desktop + mobile screenshots.
 *
 
 */
 $canonicalUrl = 'https://tri-chiwellness.com/services';
$pageTitle = 'Our Services — Tri-Chi Wellness';
$pageDescription = 'Tri-Chi Wellness offers therapy, counseling, and medication management for individuals and families who need a safe place to be heard, understood, and guided with care.';
$activeNav = 'services';
require __DIR__ . '/../layouts/header.php';
?>
<main>
  <!-- ================= SERVICES HERO ================= -->
  <section class="services-hero">
    <div class="container services-hero__row">
      <div class="services-hero__copy" data-reveal="left">
        <h1>Our services</h1>
        <p>Tri-Chi Wellness offers therapy, counseling, and medication management for individuals and families who need a safe place to be heard, understood, and guided with care.</p>
        <a href="/contact" class="btn btn--primary">Contact Us</a>
      </div>
      <div class="services-hero__images" data-reveal="right">
      <img class="services-hero__img-main" src="/assets/img/services-hero-1.png" alt="Family therapy session with counselor" loading="lazy">
      <div class="services-hero__images-right">
        <img src="/assets/img/services-hero-2.png" alt="Client speaking with a care provider" loading="lazy">
        <div class="services-hero__marquee">
          <div class="services-hero__marquee-track">
            <span>You don’t have to figure it out alone.</span>
            <span>You don’t have to figure it out alone.</span>
            <span>You don’t have to figure it out alone..</span>
            <span>You don’t have to figure it out alone.</span>
          </div>
        </div>
      </div>
    </div>
    </div>
    <div class="container stats__grid stats--no-border">
        <div class="stat" data-reveal="up">
            <div class="stat__number" data-count-to="500" data-suffix="+">0+</div>
            <div class="stat__label">Clients Supported</div>
          </div>
          <div class="stat" data-reveal="up" data-reveal-delay="200">
            <div class="stat__number" data-count-to="10" data-suffix="+">0+</div>
            <div class="stat__label">Years of Care Experience</div>
          </div>
          <div class="stat" data-reveal="up" data-reveal-delay="400">
            <div class="stat__number" data-count-to="48" data-prefix="24&ndash;" data-suffix="h">24&ndash;0h</div>
            <div class="stat__label">Inquiry Response Time</div>
          </div>
          <div class="stat" data-reveal="up" data-reveal-delay="600">
            <div class="stat__number" data-count-to="100" data-suffix="%">0%</div>
            <div class="stat__label">Confidential Communication</div>
      </div>
    </div>
  </section>
  <?php require __DIR__ . '/../partials/_services-preview.php'; ?>
  <?php require __DIR__ . '/../partials/_testimonials.php'; ?>
  <?php require __DIR__ . '/../partials/_faq.php'; ?>
</main>
<?php require __DIR__ . '/../layouts/footer.php'; ?>