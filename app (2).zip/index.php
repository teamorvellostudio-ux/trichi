<?php
declare(strict_types=1);

/**
 * Front controller.
 *
 * IMPORTANT — path assumes this exact host layout:
 *   public_html/index.php   (this file)
 *   public_html/app/...     (views — sibling of this file, NOT one level up)
 *   public_html/assets/...
 */

// Secure session cookie settings — httponly prevents JS access (XSS
// mitigation), samesite=Lax is a sane default for a form-posting site,
// secure=true only sends the cookie over HTTPS (safe now that SSL is
// confirmed active site-wide).
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();

require __DIR__ . '/app/Controllers/ContactController.php';

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = rtrim($uri, '/');
if ($uri === '') { $uri = '/'; }

switch ($uri) {
    case '/':
        require __DIR__ . '/app/Views/home/index.php';
        break;

    case '/about':
        require __DIR__ . '/app/Views/about/index.php';
        break;

    case '/services':
        require __DIR__ . '/app/Views/services/index.php';
        break;

    case '/contact':
        require __DIR__ . '/app/Views/contact/index.php';
        break;

    case '/contact/submit':
        contact_handle_submit();
        break;

    default:
        http_response_code(404);
        echo '404 — Page not found';
        break;
}