Place the real hero photo here as `hero-support.jpg` (the therapist/client
photo from the hero card row). A placeholder was used during layout
verification since the actual image asset wasn't included in the
screenshots — only its position, rounding, and overlay pill were visible.
