document.addEventListener('DOMContentLoaded', function () {
  var toggle = document.getElementById('navToggle');
  var closeBtn = document.getElementById('navClose');
  var menu = document.getElementById('mobileMenu');

  function openMenu() {
    menu.classList.add('is-open');
    toggle.setAttribute('aria-expanded', 'true');
    document.body.classList.add('menu-open');
  }

  function closeMenu() {
    menu.classList.remove('is-open');
    toggle.setAttribute('aria-expanded', 'false');
    document.body.classList.remove('menu-open');
  }

  if (toggle && menu) {
    toggle.addEventListener('click', function () {
      if (menu.classList.contains('is-open')) {
        closeMenu();
      } else {
        openMenu();
      }
    });

    if (closeBtn) {
      closeBtn.addEventListener('click', closeMenu);
    }

    menu.querySelectorAll('.mobile-menu__links a').forEach(function (link) {
      link.addEventListener('click', closeMenu);
    });
  }

  var track = document.querySelector('[data-carousel]');
    if (track) {
      var slides = Array.prototype.slice.call(track.querySelectorAll('.carousel__slide'));
      var total = slides.length;
      var activeIndex = Math.floor(total / 2);
      function render() {
        slides.forEach(function (slide, i) {
          var diff = i - activeIndex;
          if (diff > total / 2) diff -= total;
          if (diff < -total / 2) diff += total;
          if (diff < -2 || diff > 2) {
            slide.setAttribute('data-pos', 'hidden');
          } else {
            slide.setAttribute('data-pos', String(diff));
          }
        });
      }
      function next() {
        activeIndex = (activeIndex + 1) % total;
        render();
      }
      render();
      setInterval(next, 2200);   // was 3200ms, no more pause-on-hover
    }

  document.querySelectorAll('.marquee-col__inner').forEach(function (inner) {
    inner.innerHTML += inner.innerHTML;
  });

  document.querySelectorAll('.faq__item').forEach(function (item) {
    var question = item.querySelector('.faq__question');
    var answer = item.querySelector('.faq__answer');

    question.addEventListener('click', function () {
      var isOpen = item.classList.contains('is-open');

      document.querySelectorAll('.faq__item.is-open').forEach(function (openItem) {
        if (openItem !== item) {
          openItem.classList.remove('is-open');
          openItem.querySelector('.faq__answer').style.maxHeight = null;
        }
      });

      if (isOpen) {
        item.classList.remove('is-open');
        answer.style.maxHeight = null;
      } else {
        item.classList.add('is-open');
        answer.style.maxHeight = answer.scrollHeight + 'px';
      }
    });
  });
  
});

 document.addEventListener('DOMContentLoaded', function () {

  /* --------------------------------------------------------- 
     Scroll-reveal: fade/slide elements in as they enter the 
     viewport. Elements opt in via data-reveal="up|left|right|fade" 
     and can stagger with data-reveal-delay="150" (milliseconds). 
     --------------------------------------------------------- */
  var revealEls = document.querySelectorAll('[data-reveal]');
  if (revealEls.length) {
    if ('IntersectionObserver' in window) {
      var revealObserver = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            revealObserver.unobserve(entry.target);
          }
        });
      }, { threshold: 0.15, rootMargin: '0px 0px -40px 0px' });
      revealEls.forEach(function (el) {
        var delay = el.getAttribute('data-reveal-delay');
        if (delay) el.style.transitionDelay = delay + 'ms';
        revealObserver.observe(el);
      });
    } else {
      revealEls.forEach(function (el) { el.classList.add('is-visible'); });
    }
  }

  /* --------------------------------------------------------- 
     Stats counter: animates the number up from 0 once its stat 
     card scrolls into view. Markup contract: 
       <span data-count-to="500" data-prefix="" data-suffix="+">0+</span> 
     --------------------------------------------------------- */
  var countEls = document.querySelectorAll('[data-count-to]');
  if (countEls.length && 'IntersectionObserver' in window) {
    var countObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          animateCount(entry.target);
          countObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.5 });
    countEls.forEach(function (el) { countObserver.observe(el); });
  } else {
    countEls.forEach(function (el) {
      var prefix = el.getAttribute('data-prefix') || '';
      var suffix = el.getAttribute('data-suffix') || '';
      el.textContent = prefix + el.getAttribute('data-count-to') + suffix;
    });
  }

  function animateCount(el) {
    var target = parseInt(el.getAttribute('data-count-to'), 10);
    var prefix = el.getAttribute('data-prefix') || '';
    var suffix = el.getAttribute('data-suffix') || '';
    var duration = 2200;
    var startTime = null;
    function step(timestamp) {
      if (startTime === null) startTime = timestamp;
      var progress = Math.min((timestamp - startTime) / duration, 1);
      var eased = 1 - Math.pow(1 - progress, 3);
      var current = Math.floor(eased * target);
      el.textContent = prefix + current + suffix;
      if (progress < 1) {
        requestAnimationFrame(step);
      } else {
        el.textContent = prefix + target + suffix;
      }
    }
    requestAnimationFrame(step);
  }
  
  
  
  
  var contactForm = document.querySelector('.contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', function () {
      var submitBtn = contactForm.querySelector('.contact-form__submit');
      if (submitBtn) {
        submitBtn.classList.add('is-loading');
        submitBtn.setAttribute('aria-busy', 'true');
      }
    });
  }

  document.querySelectorAll('.form-flash').forEach(function (toast) {
    var closeBtn = toast.querySelector('.form-flash__close');

    function dismiss() {
      toast.classList.add('is-hiding');
      setTimeout(function () { toast.remove(); }, 300);
    }

    var timer = setTimeout(dismiss, 5000);

    if (closeBtn) {
      closeBtn.addEventListener('click', function () {
        clearTimeout(timer);
        dismiss();
      });
    }
  });

});